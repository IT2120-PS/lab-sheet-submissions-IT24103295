setwd("C:\\Users\\it24103295\\Downloads\\it24103295")
branch_data<-read.table("Exercise.txt", header = TRUE,sep = " ")
fix(data)
attach(branch_data)

str(branch_data)
# Scale of measurement:
# - Branch is a categorical variable (nominal scale).
# - Sales_X1 is a quantitative variable (ratio scale).
# - Advertising_X2 is a quantitative variable (ratio scale).
# - Years_X3 is a quantitative variable (ratio scale).

 boxplot(branch_data$Branch.Sales_X1, main = "Box plot for Sales", ylab = "Sales", col = "lightblue")

boxplot(Branch.Sales_X1, 
        main = "Boxplot of Sales", 
        ylab = "Sales", 
        col = "lightblue", 
        border = "darkblue",
        horizontal = TRUE,
        outline = FALSE)
branch_data <- read.csv("Exercise.txt", header = TRUE)
head(branch_data)
colnames(branch_data) <- c("Branch", "Sales", "Advertising", "Years")

boxplot(branch_data$Sales,
        main = "Boxplot of Sales",
        col = "lightblue",
        ylab = "Sales")


fivenum(branch_data$Advertising)
IQR(branch_data$Advertising)

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3 - Q1
  lower <- Q1 - 1.5*IQR_val
  upper <- Q3 + 1.5*IQR_val
  return(x[x < lower | x > upper])
}

find_outliers(branch_data$Years)
